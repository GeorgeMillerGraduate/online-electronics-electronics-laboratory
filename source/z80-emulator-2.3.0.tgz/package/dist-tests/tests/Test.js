// Regression test for the Z80.
import { hi } from "z80-base";
import { CpuEvent, CpuEventType, Runner } from "z80-test";
import { Z80 } from "../src/Z80.js";
/**
 * HAL for the test suite.
 */
class HalImpl {
    constructor() {
        this.memory = new Uint8Array(64 * 1024);
        this.events = [];
        this.tStateCount = 0;
    }
    reset() {
        this.memory.fill(0);
        this.events = [];
        this.tStateCount = 0;
    }
    contendMemory(address) {
        this.events.push(new CpuEvent(this.tStateCount, CpuEventType.MEMORY_CONTEND, address));
    }
    contendPort(address) {
        this.events.push(new CpuEvent(this.tStateCount, CpuEventType.PORT_CONTEND, address));
    }
    readMemory(address) {
        const value = this.memory[address];
        this.events.push(new CpuEvent(this.tStateCount, CpuEventType.MEMORY_READ, address, value));
        return value;
    }
    readPort(address) {
        const value = hi(address); // For testing.
        this.events.push(new CpuEvent(this.tStateCount, CpuEventType.PORT_READ, address, value));
        return value;
    }
    writeMemory(address, value) {
        this.events.push(new CpuEvent(this.tStateCount, CpuEventType.MEMORY_WRITE, address, value));
        this.memory[address] = value;
    }
    writePort(address, value) {
        this.events.push(new CpuEvent(this.tStateCount, CpuEventType.PORT_WRITE, address, value));
    }
}
/**
 * Delegate for the test suite.
 */
class DelegateImpl {
    constructor() {
        this.hal = new HalImpl();
        this.z80 = new Z80(this.hal);
    }
    startNewTest(name) {
        // console.log("Running test \"" + name + "\"");
        this.z80.reset();
        this.hal.reset();
    }
    getRegister(register) {
        const value = this.z80.regs[register];
        // console.log("Checking value of " + Register[register] + " (" + toHex(value, 4) + ")");
        return value;
    }
    readMemory(address) {
        const value = this.hal.memory[address];
        // console.log("Checking value of " + toHex(address, 4) + " (" + toHex(value, 2) + ")");
        return value;
    }
    run(tStateCount) {
        // console.log("Running for " + tStateCount + " t-states");
        while (this.hal.tStateCount < tStateCount) {
            this.z80.step();
        }
        return this.hal.events;
    }
    setRegister(register, value) {
        // console.log("Setting register " + Register[register] + " to " + toHex(value, 4));
        this.z80.regs[register] = value;
    }
    writeMemory(address, value) {
        // console.log("Writing " + toHex(value, 2) + " to " + toHex(address, 4));
        this.hal.memory[address] = value;
    }
    getTStateCount() {
        return this.hal.tStateCount;
    }
}
// Run the test.
const delegate = new DelegateImpl();
const runner = new Runner(delegate);
runner.checkEvents = false;
runner.checkTStates = true;
runner.checkContend = false;
runner.loadTests();
if (true) {
    runner.runAll();
}
else {
    runner.checkEvents = true;
    runner.runOne("ed7a");
}
for (const error of runner.errors) {
    console.log(error);
}
console.log(`Passed ${runner.successfulTests} of ${runner.tests.size} (${Math.round(runner.successfulTests * 100 / runner.tests.size)}%) with ${runner.errors.length} errors`);
//# sourceMappingURL=Test.js.map