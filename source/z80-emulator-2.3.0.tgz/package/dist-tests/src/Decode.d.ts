import { Z80 } from "./Z80";
/**
 * Decode the base (un-prefixed) instructions.
 */
export declare function decode(z80: Z80): void;
//# sourceMappingURL=Decode.d.ts.map