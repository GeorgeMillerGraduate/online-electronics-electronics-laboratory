import { Flag, hi, inc16, lo, RegisterSet, word } from "z80-base";
import { decode } from "./Decode.js";
/**
 * Emulated Z80 processor.
 */
export class Z80 {
    constructor(hal) {
        /**
         * Full set of registers.
         */
        this.regs = new RegisterSet();
        /**
         * Tables for computing flags. Public so that the decoding function
         * can access them.
         */
        this.sz53Table = []; /* The S, Z, 5 and 3 bits of the index */
        this.parityTable = []; /* The parity of the lookup value */
        this.sz53pTable = []; /* OR the above two tables together */
        this.hal = hal;
        this.initTables();
    }
    /**
     * Reset the Z80 to a known state.
     */
    reset() {
        this.regs = new RegisterSet();
    }
    /**
     * Execute one instruction.
     */
    step() {
        decode(this);
    }
    /**
     * Increment the clock count.
     */
    incTStateCount(count) {
        this.hal.tStateCount += count;
    }
    /**
     * Interrupt the CPU with a maskable interrupt
     */
    maskableInterrupt() {
        if (this.regs.iff1 !== 0) {
            this.interrupt(true);
        }
    }
    /**
     * Interrupt the CPU with a non-maskable interrupt
     */
    nonMaskableInterrupt() {
        this.interrupt(false);
    }
    /**
     * Read a byte from memory, taking as many clock cycles as necessary.
     */
    readByte(address) {
        this.incTStateCount(3);
        return this.readByteInternal(address);
    }
    /**
     * Reads a word at the specified address. Reads the low byte first.
     */
    readWord(address) {
        const lowByte = this.readByte(address);
        const highByte = this.readByte(address + 1);
        return word(highByte, lowByte);
    }
    /**
     * Read a byte from memory (not affecting clock).
     */
    readByteInternal(address) {
        return this.hal.readMemory(address);
    }
    /**
     * Write a byte to memory, taking as many clock cycles as necessary.
     */
    writeByte(address, value) {
        this.incTStateCount(3);
        this.writeByteInternal(address, value);
    }
    /**
     * Write a byte to memory (not affecting clock).
     */
    writeByteInternal(address, value) {
        this.hal.writeMemory(address, value);
    }
    /**
     * Write a byte to a port, taking as many clock cycles as necessary.
     */
    writePort(address, value) {
        this.incTStateCount(1);
        this.hal.writePort(address, value);
        this.incTStateCount(3);
    }
    /**
     * Read a byte from a port, taking as many clock cycles as necessary.
     */
    readPort(address) {
        this.incTStateCount(1);
        const value = this.hal.readPort(address);
        this.incTStateCount(3);
        return value;
    }
    /**
     * Push a word on the stack.
     */
    pushWord(value) {
        this.pushByte(hi(value));
        this.pushByte(lo(value));
    }
    /**
     * Push a byte on the stack.
     */
    pushByte(value) {
        this.regs.sp = (this.regs.sp - 1) & 0xFFFF;
        this.writeByte(this.regs.sp, value);
    }
    /**
     * Pop a word from the stack.
     */
    popWord() {
        const lowByte = this.popByte();
        const highByte = this.popByte();
        return word(highByte, lowByte);
    }
    /**
     * Pop a byte from the stack.
     */
    popByte() {
        const value = this.readByte(this.regs.sp);
        this.regs.sp = inc16(this.regs.sp);
        return value;
    }
    /**
     * Process either kind of interrupt. If maskable, assumes that
     * the mask has already been checked.
     */
    interrupt(maskable) {
        if (this.regs.halted) {
            // Skip past HALT instruction.
            this.regs.pc++;
            this.regs.halted = 0;
        }
        this.incTStateCount(7);
        this.regs.r += 1;
        this.regs.iff1 = 0;
        this.regs.iff2 = 0;
        this.pushWord(this.regs.pc);
        if (maskable) {
            switch (this.regs.im) {
                case 0:
                case 1:
                    this.regs.pc = 0x0038;
                    break;
                case 2: {
                    // The LSB here is taken from the data bus, so it's
                    // unpredictable. We use 0xFF but any value would do.
                    const address = word(this.regs.i, 0xFF);
                    this.regs.pc = this.readWord(address);
                    break;
                }
                default:
                    throw new Error("Unknown im mode " + this.regs.im);
            }
        }
        else {
            this.regs.pc = 0x0066;
        }
    }
    initTables() {
        for (let i = 0; i < 0x100; i++) {
            this.sz53Table.push(i & (Flag.X3 | Flag.X5 | Flag.S));
            let bits = i;
            let parity = 0;
            for (let bit = 0; bit < 8; bit++) {
                parity ^= bits & 1;
                bits >>= 1;
            }
            this.parityTable.push(parity ? 0 : Flag.P);
            this.sz53pTable.push(this.sz53Table[i] | this.parityTable[i]);
        }
        this.sz53Table[0] |= Flag.Z;
        this.sz53pTable[0] |= Flag.Z;
    }
}
//# sourceMappingURL=Z80.js.map