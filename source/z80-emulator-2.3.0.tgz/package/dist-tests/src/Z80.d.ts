import { RegisterSet } from "z80-base";
import { Hal } from "./Hal.js";
/**
 * Emulated Z80 processor.
 */
export declare class Z80 {
    /**
     * Full set of registers.
     */
    regs: RegisterSet;
    /**
     * Hardware abstraction layer this Z80 is dealing with.
     */
    hal: Hal;
    /**
     * Tables for computing flags. Public so that the decoding function
     * can access them.
     */
    sz53Table: number[];
    parityTable: number[];
    sz53pTable: number[];
    constructor(hal: Hal);
    /**
     * Reset the Z80 to a known state.
     */
    reset(): void;
    /**
     * Execute one instruction.
     */
    step(): void;
    /**
     * Increment the clock count.
     */
    incTStateCount(count: number): void;
    /**
     * Interrupt the CPU with a maskable interrupt
     */
    maskableInterrupt(): void;
    /**
     * Interrupt the CPU with a non-maskable interrupt
     */
    nonMaskableInterrupt(): void;
    /**
     * Read a byte from memory, taking as many clock cycles as necessary.
     */
    readByte(address: number): number;
    /**
     * Reads a word at the specified address. Reads the low byte first.
     */
    readWord(address: number): number;
    /**
     * Read a byte from memory (not affecting clock).
     */
    readByteInternal(address: number): number;
    /**
     * Write a byte to memory, taking as many clock cycles as necessary.
     */
    writeByte(address: number, value: number): void;
    /**
     * Write a byte to memory (not affecting clock).
     */
    writeByteInternal(address: number, value: number): void;
    /**
     * Write a byte to a port, taking as many clock cycles as necessary.
     */
    writePort(address: number, value: number): void;
    /**
     * Read a byte from a port, taking as many clock cycles as necessary.
     */
    readPort(address: number): number;
    /**
     * Push a word on the stack.
     */
    pushWord(value: number): void;
    /**
     * Push a byte on the stack.
     */
    pushByte(value: number): void;
    /**
     * Pop a word from the stack.
     */
    popWord(): number;
    /**
     * Pop a byte from the stack.
     */
    popByte(): number;
    /**
     * Process either kind of interrupt. If maskable, assumes that
     * the mask has already been checked.
     */
    private interrupt;
    private initTables;
}
//# sourceMappingURL=Z80.d.ts.map