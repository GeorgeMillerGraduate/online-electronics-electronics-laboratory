export * from "./Z80";
export * from "./Hal";
//# sourceMappingURL=index.d.ts.map